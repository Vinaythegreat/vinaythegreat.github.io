import marina from "./assets/marina.jpg";
import trysmartImg from "./assets/trysmart.jpg";
import formsImg from "./assets/forms.jpg";
import signalImg from "./assets/signal.jpg";
import portrait from "./assets/vinay.jpg";

export const LINKS = {
  linkedin: "https://www.linkedin.com/in/vinayagamoorthyn/",
  trysmart: "http://trysmart.in/",
  sololearn: "https://www.sololearn.com/Profile/549874/",
};

export const portraitSrc = portrait;
export const marinaSrc = marina;

export const nav = [
  { id: "about", en: "About", ta: "பற்றி" },
  { id: "path", en: "Path", ta: "பாதை" },
  { id: "work", en: "Work", ta: "வேலை" },
  { id: "record", en: "Record", ta: "பதிவு" },
  { id: "contact", en: "Contact", ta: "தொடர்பு" },
] as const;

export const roles = [
  {
    id: "comcast",
    when: "Now",
    org: "Comcast",
    place: "Chennai, Tamil Nadu",
    line: "Current employer on the public profile.",
    detail:
      "Vinay is listed at Comcast’s Chennai office. The public page does not publish an internal title or a project list, so this site does not invent one. What it does say, in his own about line: an innovative web developer with eight years building and maintaining the web.",
    notes: [
      "Chennai is the published location for this role.",
      "The profile title reads Vinayagamoorthy N — Comcast.",
      "He shares Comcast workplace notes, including Great Place to Work recognition.",
    ],
  },
  {
    id: "alytsee",
    when: "Previously",
    org: "ALYTSEE Technologies",
    place: "Role location not published",
    line: "IT services and consulting, linked from the experience list.",
    detail:
      "The company mark on this chapter is ALYTSEE Technologies — an IT services firm known for analytics, cloud, and support work. His public entry does not name a title, dates, or a city, so those stay blank.",
    notes: [
      "Company context only: analytics, cloud, and customer support tracks.",
      "Nothing here claims a personal stack beyond the profile itself.",
    ],
  },
  {
    id: "yuniq",
    when: "Earlier",
    org: "YuniQ",
    place: "Chennai, Tamil Nadu",
    line: "Formerly Tekclan Software Solutions. The profile still carries that logo file.",
    detail:
      "This Chennai chapter points at the studio now called YuniQ. The image on the profile is served from a file still named tekclan_logo — the company page rebranded; the experience entry did not. YuniQ builds enterprise software: document generation, process automation, Salesforce, and BPM. Those are the studio’s products, not a private task list.",
    notes: [
      "Published location: Chennai.",
      "Company page: yuniq.co, headquartered in Tharamani.",
    ],
  },
] as const;

export type WorkCategory = "All" | "Product" | "Integration" | "Now";

export const works = [
  {
    id: "trysmart",
    category: "Product" as const,
    kicker: "Apr 2016 — Jun 2016",
    title: "trysmart.in",
    summary:
      "The Indian try-before-you-buy for gadgets. A WordPress and Divi build asked to match Lumoid, closely.",
    image: trysmartImg,
    alt: "Camera, lens, and a folded drone on a sunlit oak desk",
    stack: ["WordPress", "Divi Builder", "HTML / CSS", "JavaScript"],
    story: [
      "Listed on LinkedIn as trysmart.in, April to June 2016.",
      "His description: Trysmart, the Indian version of lumoid.com, also demanded an exact clone of Lumoid on WordPress using Divi Builder.",
      "Lumoid was a try-before-you-buy service for photography and video gear. The brief was fidelity — same idea, Indian audience, a page-builder implementation rather than a from-scratch app.",
    ],
    link: { href: LINKS.trysmart, label: "trysmart.in" },
    source: "LinkedIn project entry, written by Vinayagamoorthy N.",
  },
  {
    id: "forms",
    category: "Integration" as const,
    kicker: "Shipped with a colleague",
    title: "FormStack, made trustworthy",
    summary:
      "Fraud filters, a document.write fix, and HIPAA-minded encryption — problems the platform itself had not closed.",
    image: formsImg,
    alt: "Blank forms, a brass key, and a wax seal on a dark desk",
    stack: ["FormStack", "ClickCease", "Form encryption", "HIPAA-minded forms"],
    story: [
      "A recommendation on the profile names the work directly. After research showed no one had solved the problem, Vinay did — and left a version that could be repeated inside and outside the organization.",
      "Deployed together: a ClickCease fraud-mitigation integration with FormStack, a FormStack document.write fix, HIPAA-compliant form encryption, and three further FormStack fixes the vendor had not shipped.",
      "The note spells HIPAA as “Hippa.” The work described is compliant form encryption. Implementation detail is not public, so it is not reconstructed here.",
    ],
    source: "LinkedIn recommendation received by Vinayagamoorthy N.",
  },
  {
    id: "now",
    category: "Now" as const,
    kicker: "Chennai · current",
    title: "Building and maintaining",
    summary:
      "Eight years of the unglamorous craft: keep the web standing, then make the next fix reusable.",
    image: signalImg,
    alt: "Fiber optic strands glowing teal and amber beside a network switch",
    stack: ["Web development", "Maintenance", "Cross-team delivery"],
    story: [
      "The public about line begins: “Innovative Web Developer with 8 years of total experience in building and maintaining…” LinkedIn cuts the sentence there for guests.",
      "The current chapter is Comcast, Chennai. No internal product names are published, and none are guessed.",
      "The through-line, from the recommendation and the about line together: he takes a hard web problem and leaves something other people can run.",
    ],
    source: "LinkedIn about line and current experience entry.",
  },
];

export const fixes = [
  {
    id: "clickcease",
    title: "ClickCease × FormStack",
    text: "Fraud-mitigation wired into FormStack so junk and paid-click abuse could be stopped at the form, not cleaned up later.",
  },
  {
    id: "docwrite",
    title: "document.write fix",
    text: "A FormStack document.write issue, closed. The public note does not include the patch, only that it shipped.",
  },
  {
    id: "hipaa",
    title: "HIPAA-minded encryption",
    text: "Form encryption described by a colleague as HIPAA compliant. Quoted on the profile as “Hippa compliant form encryption.”",
  },
  {
    id: "more",
    title: "Three vendor-open fixes",
    text: "Three further FormStack issues the platform itself had not fixed. Named as a set, not itemized — so they stay a set.",
  },
] as const;

export const skills = [
  {
    name: "JavaScript",
    evidence: "SoloLearn Certificate of Completion, February 2016. Credential 1024-549874.",
  },
  {
    name: "Java",
    evidence: "SoloLearn Certificate of Completion, February 2016. Credential 1068-549874.",
  },
  {
    name: "WordPress & Divi",
    evidence: "trysmart.in, April–June 2016: an exact Lumoid-style build on WordPress with Divi Builder.",
  },
  {
    name: "HTML & CSS",
    evidence: "The same page-builder web work, plus eight years described as building and maintaining the web.",
  },
  {
    name: "Android basics",
    evidence: "Android Basics Nanodegree by Google, Udacity, issued July 2016.",
  },
  {
    name: "FormStack",
    evidence: "Colleague recommendation: integrations and multiple production fixes.",
  },
  {
    name: "ClickCease",
    evidence: "Fraud-mitigation integration with FormStack, named in that recommendation.",
  },
  {
    name: "Form encryption",
    evidence: "HIPAA-minded form encryption, named in that recommendation.",
  },
] as const;

export const certs = [
  {
    title: "Android Basics Nanodegree by Google",
    by: "Udacity",
    when: "Issued July 2016",
    href: "",
  },
  {
    title: "Java Course",
    by: "SoloLearn",
    when: "Issued February 2016 · ID 1068-549874",
    href: LINKS.sololearn,
  },
  {
    title: "JavaScript Basics",
    by: "SoloLearn",
    when: "Issued February 2016 · ID 1024-549874",
    href: LINKS.sololearn,
  },
  {
    title: "Spanish Fluency: Beginner",
    by: "Duolingo",
    when: "Issued December 2015 · estimated beginner",
    href: "",
  },
  {
    title: "Become a Programmer",
    by: "Lynda.com",
    when: "Completed April 2016",
    href: "",
  },
] as const;

export const quote = {
  text: "Vinay is a rare talent who is always one step ahead. He's trustworthy, intelligent and hard working. On one project, I gave him a task. After researching, I knew that there was not one person that had ever solved the problem. Not only did Vinay solve the problem, but he solved it in a way that made it easily implemented and replicable in and outside the organization.",
  more: "I hope to be able to continue to work with Vinay on future projects. Here are a few we were able to successfully deploy together: Click Cease fraud mitigation integration with FormStack, FormStack document.write fix, Hippa compliant form encryption, 3 other FormStack fixes that FormStack still has not fixed. No matter where I go, I'll be sure to call on Vinay.",
  by: "A colleague, on LinkedIn. The recommender’s name is not public.",
};
