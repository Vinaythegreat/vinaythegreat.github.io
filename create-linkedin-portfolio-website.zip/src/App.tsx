import { useEffect, useId, useMemo, useRef, useState } from "react";
import {
  LINKS,
  certs,
  fixes,
  marinaSrc,
  nav,
  portraitSrc,
  quote,
  roles,
  skills,
  works,
  type WorkCategory,
} from "./data";

type Lang = "en" | "ta";

function useChennaiClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  }).format(now);
}

function useInView<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setSeen(true);
      },
      { threshold: 0.35 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return { ref, seen };
}

function useCount(target: number, run: boolean) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!run) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setValue(target);
      return;
    }
    const start = performance.now();
    let frame = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / 900);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(target * eased));
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [run, target]);
  return value;
}

function label(lang: Lang, en: string, ta: string) {
  return lang === "ta" ? ta : en;
}

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [active, setActive] = useState("about");
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const [openRole, setOpenRole] = useState<string>("comcast");
  const [filter, setFilter] = useState<WorkCategory>("All");
  const [openWork, setOpenWork] = useState<string | null>(null);
  const [openFix, setOpenFix] = useState<string>("clickcease");
  const [skill, setSkill] = useState<string>(skills[0].name);
  const [toast, setToast] = useState("");
  const clock = useChennaiClock();
  const stats = useInView<HTMLDivElement>();
  const years = useCount(8, stats.seen);
  const connections = useCount(427, stats.seen);
  const papers = useCount(7, stats.seen);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const nodes = nav
      .map((item) => document.getElementById(item.id))
      .filter((node): node is HTMLElement => Boolean(node));
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0.15, 0.4] },
    );
    nodes.forEach((node) => io.observe(node));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(""), 2800);
    return () => window.clearTimeout(id);
  }, [toast]);

  const visibleWorks = useMemo(
    () => (filter === "All" ? works : works.filter((item) => item.category === filter)),
    [filter],
  );
  const activeWork = works.find((item) => item.id === openWork) ?? null;
  const activeSkill = skills.find((item) => item.name === skill) ?? skills[0];

  function go(id: string) {
    setMenu(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function copy(text: string, message: string) {
    try {
      await navigator.clipboard.writeText(text);
      setToast(message);
    } catch {
      setToast("Copy was blocked by the browser. The LinkedIn link is still in the button.");
    }
  }

  function downloadCard() {
    const card = [
      "BEGIN:VCARD",
      "VERSION:3.0",
      "N:N;Vinayagamoorthy;;;",
      "FN:Vinayagamoorthy N",
      "TITLE:Web Developer",
      "ORG:Comcast",
      "ADR;TYPE=WORK:;;;Chennai;Tamil Nadu;;India",
      `URL:${LINKS.linkedin}`,
      "LANG:en,ta,te",
      "NOTE:Innovative web developer. Public profile only — no email is published.",
      "END:VCARD",
    ].join("\r\n");
    const blob = new Blob([card], { type: "text/vcard" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "vinayagamoorthy-n.vcf";
    a.click();
    URL.revokeObjectURL(url);
    setToast("Contact card saved. It carries the public profile, not a private email.");
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <a
        href="#about"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[80] focus:bg-cream focus:px-3 focus:py-2"
      >
        Skip to content
      </a>

      <header
        className={`fixed inset-x-0 top-0 z-40 transition-colors ${
          scrolled || menu ? "bg-night/95 text-cream shadow-lg shadow-night/20" : "bg-transparent text-cream"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="flex items-center gap-2 text-left">
            <span className="grid h-8 w-8 place-items-center rounded-md bg-saffron font-display text-lg text-cream">V</span>
            <span className="hidden leading-tight sm:block">
              <span className="block text-sm font-medium tracking-wide">Vinayagamoorthy N</span>
              <span className="block text-[11px] uppercase tracking-[0.18em] text-cream/70">Web developer</span>
            </span>
          </button>

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
            {nav.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className={`rounded-full px-3 py-1.5 text-sm ${
                  active === item.id ? "bg-cream/15 text-cream" : "text-cream/75 hover:text-cream"
                }`}
                aria-current={active === item.id ? "true" : undefined}
              >
                {label(lang, item.en, item.ta)}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLang((value) => (value === "en" ? "ta" : "en"))}
              className="rounded-full border border-cream/25 px-3 py-1.5 text-xs tracking-wide text-cream"
              aria-pressed={lang === "ta"}
            >
              {lang === "en" ? "தமிழ்" : "EN"}
            </button>
            <a
              href={LINKS.linkedin}
              target="_blank"
              rel="noreferrer"
              className="hidden rounded-full bg-saffron px-3 py-1.5 text-sm font-medium text-cream hover:bg-saffron-deep sm:inline-flex"
            >
              LinkedIn
            </a>
            <button
              type="button"
              className="grid h-10 w-10 place-items-center rounded-full border border-cream/25 lg:hidden"
              aria-expanded={menu}
              aria-label={menu ? "Close menu" : "Open menu"}
              onClick={() => setMenu((value) => !value)}
            >
              <span className="sr-only">Menu</span>
              <span className="flex w-4 flex-col gap-1">
                <span className={`h-px bg-cream transition ${menu ? "translate-y-[5px] rotate-45" : ""}`} />
                <span className={`h-px bg-cream ${menu ? "opacity-0" : ""}`} />
                <span className={`h-px bg-cream transition ${menu ? "-translate-y-[5px] -rotate-45" : ""}`} />
              </span>
            </button>
          </div>
        </div>
        {menu && (
          <nav className="border-t border-cream/10 px-4 py-3 lg:hidden" aria-label="Mobile">
            {nav.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className="block w-full rounded-lg px-3 py-3 text-left text-lg text-cream"
              >
                {label(lang, item.en, item.ta)}
              </button>
            ))}
          </nav>
        )}
        <Progress />
      </header>

      <section className="grain relative min-h-[100svh] overflow-hidden text-cream">
        <img src={marinaSrc} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-night/80 via-night/55 to-night" />
        <div className="relative z-10 mx-auto flex min-h-[100svh] max-w-6xl flex-col justify-end px-4 pb-10 pt-28 sm:px-6 sm:pb-14">
          <div className="rise grid items-end gap-8 lg:grid-cols-[1fr_180px]">
            <div>
              <p className="mb-4 text-sm uppercase tracking-[0.28em] text-cream/75">
                {lang === "ta" ? "வணக்கம் · சென்னை" : "Vanakkam · Chennai"}
              </p>
              <h1 className="font-display text-[clamp(3.3rem,9vw,7.4rem)] leading-[0.86] tracking-[-0.045em]">
                <span className="block">Vinayaga</span>
                <span className="block">
                  moorthy <span className="text-saffron">N</span>
                </span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-cream/85 sm:text-xl">
                Web developer at Comcast. Eight years building and maintaining the web — and, when a problem has never been solved, a fix other people can reuse.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => go("work")}
                  className="rounded-full bg-saffron px-5 py-3 text-sm font-medium text-cream hover:bg-saffron-deep"
                >
                  {label(lang, "See the work", "வேலையைப் பார்")}
                </button>
                <a
                  href={LINKS.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-cream/30 px-5 py-3 text-sm text-cream hover:bg-cream/10"
                >
                  Public LinkedIn
                </a>
              </div>
            </div>
            <figure className="stamp hidden w-[168px] justify-self-end rounded-sm bg-cream p-2 text-ink shadow-2xl lg:block">
              <img
                src={portraitSrc}
                alt="Vinayagamoorthy N, from his LinkedIn portrait"
                width={200}
                height={200}
                className="aspect-square w-full object-cover"
              />
              <figcaption className="px-1 pb-1 pt-2 text-[11px] uppercase tracking-[0.16em] text-ink-soft">
                Vinay · Chennai
              </figcaption>
            </figure>
          </div>
          <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-cream/15 bg-cream/10 text-sm backdrop-blur-sm sm:grid-cols-4">
            <Fact k="City" v="Chennai" />
            <Fact k="Clock" v={`${clock} IST`} />
            <Fact k="Place" v="13.08° N · 80.27° E" />
            <Fact k="Craft" v="Build & maintain" />
          </dl>
        </div>
      </section>

      <main>
        <section id="about" className="scroll-mt-20 mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
          <SectionIndex n="01" en="About" ta="பற்றி" lang={lang} />
          <div className="mt-8 grid gap-12 lg:grid-cols-[1.3fr_0.7fr]">
            <div>
              <p className="font-display text-[clamp(1.8rem,4vw,3.1rem)] leading-[1.15] tracking-[-0.03em]">
                “Innovative web developer with 8 years of total experience in building and maintaining…”
              </p>
              <p className="mt-4 text-sm uppercase tracking-[0.18em] text-clay">The public about line, cut off by LinkedIn for guests.</p>
              <div className="mt-8 space-y-4 text-lg leading-relaxed text-ink-soft">
                <p>
                  Colleagues call him Vinay. The longer recommendation on his profile is more specific than the about line: trustworthy, a step ahead, and the person you hand a problem after you have already checked that nobody else has solved it.
                </p>
                <p>
                  He studied at CK College of Engineering & Technology from 2010 to 2014 — more than seven paper presentations, international conferences, and a prize in the project display. The degree title itself is not on the public page. He works in English, Tamil, and Telugu. A 2015 Duolingo certificate puts beginner Spanish on the shelf too.
                </p>
                <p>
                  This page only uses what the public profile actually shows. Titles, dates, and metrics that are not published are left open. That is a choice, not a gap in the design.
                </p>
              </div>
            </div>
            <aside className="space-y-4">
              <figure className="stamp mx-auto w-[180px] rounded-sm bg-cream p-2 shadow-xl ring-1 ring-ink/10 lg:hidden">
                <img src={portraitSrc} alt="Vinayagamoorthy N" className="aspect-square w-full object-cover" />
              </figure>
              <div ref={stats.ref} className="rounded-3xl bg-night p-6 text-cream">
                <p className="text-xs uppercase tracking-[0.22em] text-cream/60">On the record</p>
                <ul className="mt-5 space-y-5">
                  <Stat n={years} suffix=" yrs" label="Building and maintaining" />
                  <Stat n={connections} label="LinkedIn connections" />
                  <Stat n={papers} suffix="+" label="Paper presentations" />
                </ul>
              </div>
              <div className="rounded-3xl bg-sand p-6">
                <p className="text-xs uppercase tracking-[0.22em] text-clay">Also true</p>
                <ul className="mt-4 space-y-3 text-sm leading-relaxed">
                  <li>422 followers on the public profile.</li>
                  <li>Prize winner, college project display.</li>
                  <li>One public recommendation. The name is hidden; the work is not.</li>
                </ul>
              </div>
            </aside>
          </div>
        </section>

        <section id="path" className="scroll-mt-20 border-y border-ink/10 bg-cream">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
            <SectionIndex n="02" en="Path" ta="பாதை" lang={lang} />
            <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
              <h2 className="max-w-xl font-display text-4xl leading-tight tracking-[-0.03em] sm:text-5xl">
                Three named chapters. Nothing invented between them.
              </h2>
              <p className="max-w-sm text-sm leading-relaxed text-ink-soft">
                Order follows the public experience list. An earlier entry exists without a company name, so it is not shown.
              </p>
            </div>
            <ol className="relative mt-12 space-y-3 before:absolute before:bottom-8 before:left-[35px] before:top-8 before:w-px before:bg-ink/15 sm:before:left-[43px]">
              {roles.map((role, index) => {
                const open = openRole === role.id;
                return (
                  <li key={role.id} className="relative">
                    <button
                      type="button"
                      onClick={() => setOpenRole(open ? "" : role.id)}
                      aria-expanded={open}
                      className="grid w-full grid-cols-[auto_1fr_auto] items-center gap-4 rounded-2xl border border-ink/10 bg-paper px-4 py-4 text-left hover:border-saffron/50 sm:px-6"
                    >
                      <span className="relative z-10 grid h-10 w-10 place-items-center rounded-full bg-paper">
                        <span className={`h-3 w-3 rounded-full ${index === 0 ? "bg-saffron pulse-dot" : "bg-teal"}`} />
                      </span>
                      <span>
                        <span className="block text-xs uppercase tracking-[0.18em] text-clay">
                          {role.when} · {role.place}
                        </span>
                        <span className="mt-1 block font-display text-2xl tracking-[-0.03em]">{role.org}</span>
                      </span>
                      <span className="text-sm text-ink-soft" aria-hidden>
                        {open ? "Close" : "Open"}
                      </span>
                    </button>
                    {open && (
                      <div className="mx-4 rounded-b-2xl border border-t-0 border-ink/10 bg-paper px-4 py-5 sm:mx-6 sm:px-16">
                        <p className="text-lg leading-relaxed">{role.detail}</p>
                        <p className="mt-3 text-sm text-ink-soft">{role.line}</p>
                        <ul className="mt-4 space-y-2 text-sm">
                          {role.notes.map((note) => (
                            <li key={note} className="flex gap-2">
                              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-saffron" />
                              <span>{note}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </li>
                );
              })}
            </ol>
          </div>
        </section>

        <section id="work" className="scroll-mt-20 mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
          <SectionIndex n="03" en="Work" ta="வேலை" lang={lang} />
          <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
            <h2 className="max-w-xl font-display text-4xl leading-tight tracking-[-0.03em] sm:text-5xl">
              What the profile can actually point to.
            </h2>
            <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter work">
              {(["All", "Product", "Integration", "Now"] as WorkCategory[]).map((item) => (
                <button
                  key={item}
                  type="button"
                  role="tab"
                  aria-selected={filter === item}
                  onClick={() => setFilter(item)}
                  className={`rounded-full px-3 py-1.5 text-sm ${
                    filter === item ? "bg-ink text-cream" : "bg-sand text-ink hover:bg-ink/10"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-2">
            {visibleWorks.map((work) => (
              <article
                key={work.id}
                className={`group overflow-hidden rounded-3xl bg-cream ring-1 ring-ink/10 ${
                  work.id === "trysmart" ? "md:col-span-2 md:grid md:grid-cols-2" : ""
                }`}
              >
                <button type="button" onClick={() => setOpenWork(work.id)} className="block h-full text-left">
                  <div className={`relative overflow-hidden ${work.id === "trysmart" ? "h-72 md:h-full md:min-h-[360px]" : "h-56"}`}>
                    <img
                      src={work.image}
                      alt={work.alt}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]"
                    />
                  </div>
                </button>
                <div className="flex flex-col p-6">
                  <p className="text-xs uppercase tracking-[0.18em] text-clay">
                    {work.category} · {work.kicker}
                  </p>
                  <h3 className="mt-2 font-display text-3xl tracking-[-0.03em]">{work.title}</h3>
                  <p className="mt-3 flex-1 leading-relaxed text-ink-soft">{work.summary}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {work.stack.slice(0, 3).map((tag) => (
                      <span key={tag} className="rounded-full bg-sand px-2.5 py-1 text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => setOpenWork(work.id)}
                    className="mt-5 self-start text-sm font-medium text-teal underline decoration-teal/30 underline-offset-4 hover:decoration-teal"
                  >
                    Open the record
                  </button>
                </div>
              </article>
            ))}
          </div>

          <div className="mt-8 rounded-3xl bg-night p-6 text-cream sm:p-8">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-cream/55">Shipped, as named</p>
                <h3 className="mt-2 font-display text-3xl tracking-[-0.03em]">The FormStack ledger</h3>
              </div>
              <p className="max-w-sm text-sm text-cream/70">Click a line. These are the deployments a colleague listed. No extra tickets were added.</p>
            </div>
            <div className="mt-6 grid gap-3 md:grid-cols-2">
              {fixes.map((fix, index) => {
                const open = openFix === fix.id;
                return (
                  <button
                    key={fix.id}
                    type="button"
                    onClick={() => setOpenFix(fix.id)}
                    aria-pressed={open}
                    className={`rounded-2xl border p-4 text-left ${
                      open ? "border-saffron bg-cream/10" : "border-cream/15 hover:border-cream/40"
                    }`}
                  >
                    <span className="text-xs tracking-[0.16em] text-saffron">0{index + 1}</span>
                    <span className="mt-1 block font-medium">{fix.title}</span>
                    {open && <span className="mt-2 block text-sm leading-relaxed text-cream/80">{fix.text}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-sand">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-20 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
            <p className="text-xs uppercase tracking-[0.22em] text-clay">Recommendation</p>
            <blockquote>
              <p className="font-display text-2xl leading-snug tracking-[-0.02em] sm:text-3xl">“{quote.text}”</p>
              <p className="mt-6 leading-relaxed text-ink-soft">{quote.more}</p>
              <footer className="mt-6 text-sm text-clay">{quote.by}</footer>
            </blockquote>
          </div>
        </section>

        <section id="record" className="scroll-mt-20 mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
          <SectionIndex n="04" en="Record" ta="பதிவு" lang={lang} />
          <h2 className="mt-6 max-w-2xl font-display text-4xl leading-tight tracking-[-0.03em] sm:text-5xl">
            Skills with a receipt. Not a keyword cloud.
          </h2>
          <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1fr]">
            <div>
              <div className="flex flex-wrap gap-2">
                {skills.map((item) => (
                  <button
                    key={item.name}
                    type="button"
                    onClick={() => setSkill(item.name)}
                    aria-pressed={skill === item.name}
                    className={`rounded-full px-3 py-2 text-sm ${
                      skill === item.name ? "bg-teal text-cream" : "bg-sand hover:bg-ink/10"
                    }`}
                  >
                    {item.name}
                  </button>
                ))}
              </div>
              <div className="mt-5 rounded-3xl border border-ink/10 bg-cream p-6" aria-live="polite">
                <p className="text-xs uppercase tracking-[0.18em] text-clay">Evidence</p>
                <h3 className="mt-2 font-display text-3xl">{activeSkill.name}</h3>
                <p className="mt-3 leading-relaxed text-ink-soft">{activeSkill.evidence}</p>
              </div>
              <div className="mt-5 rounded-3xl bg-night p-6 text-cream">
                <p className="text-xs uppercase tracking-[0.18em] text-cream/55">Education</p>
                <h3 className="mt-2 font-display text-3xl leading-tight">CK College of Engineering & Technology</h3>
                <p className="mt-2 text-sm text-cream/70">2010 — 2014 · Cuddalore, Tamil Nadu</p>
                <p className="mt-4 leading-relaxed text-cream/85">
                  Activities and societies, in the profile’s words: over seven paper presentations, international conferences, prize winner in project display. The degree title itself is not published.
                </p>
                <p className="mt-3 text-sm text-cream/60">Schooling from 2003 to 2010 is listed without a public school name.</p>
              </div>
            </div>
            <div>
              <h3 className="text-xs uppercase tracking-[0.18em] text-clay">Licenses & certifications</h3>
              <ul className="mt-4 divide-y divide-ink/10 rounded-3xl border border-ink/10 bg-cream">
                {certs.map((cert) => (
                  <li key={cert.title} className="px-5 py-4">
                    <p className="font-medium">{cert.title}</p>
                    <p className="text-sm text-ink-soft">
                      {cert.by} · {cert.when}
                    </p>
                    {cert.href && (
                      <a href={cert.href} target="_blank" rel="noreferrer" className="mt-1 inline-block text-sm text-teal underline underline-offset-4">
                        See credential
                      </a>
                    )}
                  </li>
                ))}
              </ul>
              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  ["English", "Listed"],
                  ["Tamil", "Listed"],
                  ["Telugu", "Listed"],
                  ["Spanish", "Beginner"],
                ].map(([name, note]) => (
                  <div key={name} className="rounded-2xl bg-sand px-3 py-4">
                    <p className="font-display text-xl">{name}</p>
                    <p className="text-xs uppercase tracking-[0.14em] text-clay">{note}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <Contact
          lang={lang}
          onCopy={copy}
          onCard={downloadCard}
        />
      </main>

      <footer className="border-t border-ink/10 px-4 py-8 text-sm text-ink-soft sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
          <p>Vinayagamoorthy N · Chennai · Drawn from the public LinkedIn profile.</p>
          <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="text-teal">
            Back to top
          </button>
        </div>
      </footer>

      {activeWork && <WorkDrawer work={activeWork} onClose={() => setOpenWork(null)} />}
      {toast && (
        <div role="status" className="fixed bottom-5 left-1/2 z-[70] w-[min(92vw,420px)] -translate-x-1/2 rounded-full bg-ink px-4 py-3 text-center text-sm text-cream shadow-2xl">
          {toast}
        </div>
      )}
    </div>
  );
}

function Progress() {
  const [scale, setScale] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setScale(height > 0 ? window.scrollY / height : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="h-0.5 w-full bg-cream/10" aria-hidden>
      <div className="h-full w-full origin-left bg-saffron" style={{ transform: `scaleX(${scale})` }} />
    </div>
  );
}

function Fact({ k, v }: { k: string; v: string }) {
  return (
    <div className="px-4 py-3">
      <dt className="text-[10px] uppercase tracking-[0.18em] text-cream/55">{k}</dt>
      <dd className="mt-1 font-medium">{v}</dd>
    </div>
  );
}

function Stat({ n, suffix = "", label }: { n: number; suffix?: string; label: string }) {
  return (
    <li>
      <p className="font-display text-4xl tracking-[-0.04em]">
        {n}
        {suffix}
      </p>
      <p className="text-sm text-cream/70">{label}</p>
    </li>
  );
}

function SectionIndex({
  n,
  en,
  ta,
  lang,
  light = false,
}: {
  n: string;
  en: string;
  ta: string;
  lang: Lang;
  light?: boolean;
}) {
  return (
    <p className={`text-xs uppercase tracking-[0.22em] ${light ? "text-cream/70" : "text-clay"}`}>
      {n} · {label(lang, en, ta)}
    </p>
  );
}

function WorkDrawer({
  work,
  onClose,
}: {
  work: (typeof works)[number];
  onClose: () => void;
}) {
  const titleId = useId();
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-labelledby={titleId}>
      <button type="button" className="absolute inset-0 bg-night/60" aria-label="Close details" onClick={onClose} />
      <aside className="drawer-in absolute inset-y-0 right-0 w-full max-w-xl overflow-y-auto bg-paper shadow-2xl">
        <img src={work.image} alt="" className="h-56 w-full object-cover sm:h-72" />
        <div className="p-6 sm:p-8">
          <div className="flex items-start justify-between gap-4">
            <p className="text-xs uppercase tracking-[0.18em] text-clay">
              {work.category} · {work.kicker}
            </p>
            <button
              ref={closeRef}
              type="button"
              onClick={onClose}
              className="rounded-full border border-ink/15 px-3 py-1 text-sm"
            >
              Close
            </button>
          </div>
          <h2 id={titleId} className="mt-3 font-display text-4xl tracking-[-0.03em]">
            {work.title}
          </h2>
          <p className="mt-3 text-lg text-ink-soft">{work.summary}</p>
          <ul className="mt-6 space-y-3 leading-relaxed">
            {work.story.map((line) => (
              <li key={line} className="border-l-2 border-saffron pl-4">
                {line}
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-wrap gap-2">
            {work.stack.map((tag) => (
              <span key={tag} className="rounded-full bg-sand px-3 py-1 text-sm">
                {tag}
              </span>
            ))}
          </div>
          {"link" in work && work.link && (
            <a
              href={work.link.href}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex rounded-full bg-ink px-4 py-2 text-sm text-cream"
            >
              Visit {work.link.label}
            </a>
          )}
          <p className="mt-6 text-sm text-ink-soft">Source: {work.source}</p>
        </div>
      </aside>
    </div>
  );
}

function Contact({
  lang,
  onCopy,
  onCard,
}: {
  lang: Lang;
  onCopy: (text: string, message: string) => void;
  onCard: () => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("I read the public profile and wanted to talk about a web role.");
  const [error, setError] = useState("");

  function compose() {
    const who = name.trim();
    const note = message.trim();
    if (who.length < 2) {
      setError("Add your name — at least two characters.");
      return;
    }
    if (note.length < 12) {
      setError("Write a little more so the note is useful.");
      return;
    }
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("That email does not look complete. Leave it blank if you prefer.");
      return;
    }
    setError("");
    const text = [
      `Hello Vinayagamoorthy,`,
      ``,
      `I'm ${who}${email.trim() ? ` (${email.trim()})` : ""}.`,
      ``,
      note,
      ``,
      `— drafted from the portfolio`,
    ].join("\n");
    onCopy(text, "Note copied. LinkedIn is opening so you can paste it.");
    window.open(LINKS.linkedin, "_blank", "noopener,noreferrer");
  }

  return (
    <section id="contact" className="scroll-mt-20 bg-night text-cream">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:py-28">
        <div>
          <SectionIndex n="05" en="Contact" ta="தொடர்பு" lang={lang} light />
          <h2 className="mt-4 font-display text-4xl leading-tight tracking-[-0.03em] sm:text-5xl">
            No public email. A note you can actually send.
          </h2>
          <p className="mt-4 max-w-md leading-relaxed text-cream/75">
            The profile does not publish a phone number or an inbox. Write here, copy the note, and continue on LinkedIn — the only contact channel that is public.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={LINKS.linkedin} target="_blank" rel="noreferrer" className="rounded-full bg-saffron px-5 py-3 text-sm font-medium text-cream">
              Open LinkedIn
            </a>
            <button type="button" onClick={onCard} className="rounded-full border border-cream/25 px-5 py-3 text-sm">
              Save contact card
            </button>
            <button
              type="button"
              onClick={() => onCopy(LINKS.linkedin, "LinkedIn URL copied.")}
              className="rounded-full border border-cream/25 px-5 py-3 text-sm"
            >
              Copy profile link
            </button>
          </div>
          <figure className="mt-10 flex items-center gap-4">
            <img src={portraitSrc} alt="" className="h-16 w-16 rounded-full object-cover ring-2 ring-cream/20" />
            <figcaption>
              <p className="font-medium">Vinayagamoorthy N</p>
              <p className="text-sm text-cream/65">Web developer · Comcast · Chennai</p>
            </figcaption>
          </figure>
        </div>
        <form
          className="rounded-3xl bg-cream p-6 text-ink sm:p-8"
          onSubmit={(event) => {
            event.preventDefault();
            compose();
          }}
        >
          <label className="block text-sm font-medium" htmlFor="from-name">
            Your name
          </label>
          <input
            id="from-name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-ink/15 bg-paper px-3 py-3 outline-none"
            autoComplete="name"
            placeholder="How should he address you?"
          />
          <label className="mt-4 block text-sm font-medium" htmlFor="from-email">
            Email <span className="font-normal text-ink-soft">(optional, included in the note)</span>
          </label>
          <input
            id="from-email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="mt-2 w-full rounded-xl border border-ink/15 bg-paper px-3 py-3 outline-none"
            autoComplete="email"
            inputMode="email"
            placeholder="you@studio.com"
          />
          <label className="mt-4 block text-sm font-medium" htmlFor="from-note">
            Note
          </label>
          <textarea
            id="from-note"
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            rows={5}
            className="mt-2 w-full resize-y rounded-xl border border-ink/15 bg-paper px-3 py-3 outline-none"
          />
          {error && (
            <p className="mt-3 text-sm text-saffron-deep" role="alert">
              {error}
            </p>
          )}
          <button type="submit" className="mt-5 rounded-full bg-ink px-5 py-3 text-sm font-medium text-cream">
            Copy note and open LinkedIn
          </button>
        </form>
      </div>
    </section>
  );
}
